function loginAdmin() {
  const email = document.getElementById('adminEmail').value;
  const password = document.getElementById('adminPassword').value;

  firebase.auth().signInWithEmailAndPassword(email, password)
    .then(() => {
      document.getElementById('loginStatus').innerText = "Login successful!";
      document.getElementById('adminPanel').classList.remove('hidden');
      loadMembers();
    })
    .catch(error => {
      document.getElementById('loginStatus').innerText = "Login failed: " + error.message;
    });
}

function loadMembers() {
  const membersList = document.getElementById('membersList');
  membersList.innerHTML = "";
  firebase.database().ref('members').once('value', snapshot => {
    snapshot.forEach(child => {
      const data = child.val();
      const li = document.createElement('li');
      li.textContent = data.name + " - " + data.phone;
      membersList.appendChild(li);
    });
  });
}
