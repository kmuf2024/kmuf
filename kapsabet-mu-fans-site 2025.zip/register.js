document.getElementById('registerForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const fullName = document.getElementById('fullName').value;
  const phoneNumber = document.getElementById('phoneNumber').value;

  firebase.database().ref('members').push({
    name: fullName,
    phone: phoneNumber,
    timestamp: Date.now()
  }).then(() => {
    document.getElementById('statusMessage').innerText = "Registration successful!";
    document.getElementById('registerForm').reset();
  }).catch(err => {
    console.error(err);
    document.getElementById('statusMessage').innerText = "Failed to register.";
  });
});
